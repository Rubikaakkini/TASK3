/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Define the list of keywords
const char *keywords[] = {
    "int", "float", "if", "else", "while", "for", "return", "void", "main", "char", "double"
};
int num_keywords = sizeof(keywords) / sizeof(keywords[0]);

// Function to check if a word is a keyword
int isKeyword(const char *word) {
    for (int i = 0; i < num_keywords; i++) {
        if (strcmp(word, keywords[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

// Function to check if a character is an operator
int isOperator(char ch) {
    return ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '=' || ch == '>' || ch == '<';
}

// Function to perform lexical analysis
void lexicalAnalysis(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Error opening file");
        return;
    }

    char ch, buffer[256];
    int i = 0;

    printf("\nLexical Analysis:\n");

    while ((ch = fgetc(file)) != EOF) {
        // If the character is a letter, it might be a keyword or identifier
        if (isalpha(ch)) {
            buffer[i++] = ch;
            while ((ch = fgetc(file)) != EOF && (isalnum(ch) || ch == '_')) {
                buffer[i++] = ch;
            }
            buffer[i] = '\0';
            i = 0;
            ungetc(ch, file); // Push back the last character if it is not part of the word

            if (isKeyword(buffer)) {
                printf("Keyword: %s\n", buffer);
            } else {
                printf("Identifier: %s\n", buffer);
            }
        } 
        // If the character is a digit, it is a numeric constant
        else if (isdigit(ch)) {
            buffer[i++] = ch;
            while ((ch = fgetc(file)) != EOF && isdigit(ch)) {
                buffer[i++] = ch;
            }
            buffer[i] = '\0';
            i = 0;
            ungetc(ch, file); // Push back the last character
            printf("Numeric Constant: %s\n", buffer);
        } 
        // If the character is an operator
        else if (isOperator(ch)) {
            printf("Operator: %c\n", ch);
        } 
        // If the character is whitespace, ignore it
        else if (isspace(ch)) {
            continue;
        } 
        // If none of the above, it is treated as a special character
        else {
            printf("Special Character: %c\n", ch);
        }
    }

    fclose(file);
}

int main() {
    char filename[100];

    printf("Enter the name of the input file: ");
    scanf("%s", filename);

    lexicalAnalysis(filename);

    return 0;
}
